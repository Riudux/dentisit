package com.example.missfinanzas

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.missfinanzas.databinding.ActivityCalendarBinding

class CalendarActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCalendarBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCalendarBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Escuchar cuando el usuario cambia de fecha [cite: 68]
        binding.calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            val date = "$dayOfMonth/${month + 1}/$year"

            // Simulación de datos según tu documento
            when (dayOfMonth) {
                1 -> binding.tvDailyExpense.text = "Gastos: Comida $300"
                5 -> binding.tvDailyExpense.text = "Gastos: Transporte $150"
                else -> binding.tvDailyExpense.text = "No hay gastos registrados el $date"
            }
        }
    }
}