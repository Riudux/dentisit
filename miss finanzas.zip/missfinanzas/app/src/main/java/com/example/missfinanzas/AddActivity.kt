package com.example.missfinanzas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.missfinanzas.databinding.ActividadAddBinding
import android.widget.ArrayAdapter
import android.widget.Spinner

class AddActivity : AppCompatActivity() {
    private lateinit var binding: ActividadAddBinding
    private var currentInput = ""
    private var categoriaSeleccionada = "Comida" // Valor por defecto

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActividadAddBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configurar el selector de categorías (puedes usar un Spinner en el XML)
        val categorias = arrayOf("Comida", "Transporte", "Entretenimiento", "Renta", "Otros")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categorias)
        // Asumiendo que añades un Spinner con ID 'spinnerCategorias' en tu XML
        // binding.spinnerCategorias.adapter = adapter

        binding.btnSave.setOnClickListener {
            if (currentInput.isNotEmpty()) {
                val intent = Intent()
                intent.putExtra("MONTO", currentInput.toDouble())
                intent.putExtra("NOMBRE", "Gasto") // Aquí podrías añadir un EditText para el nombre
                intent.putExtra("CATEGORIA", categoriaSeleccionada)
                intent.putExtra("ES_INGRESO", false)
                setResult(RESULT_OK, intent)
                finish()
            }
        }
    }
    // Función para manejar los clics de los números 1-8 [cite: 24-31]
    fun onNumberClick(view: View) {
        val button = view as Button
        if (currentInput.length < 9) { // Límite de dígitos
            currentInput += button.text
            updateAmountDisplay()
        }
    }

    private fun updateAmountDisplay() {
        if (currentInput.isEmpty()) {
            binding.tvAmount.text = "$ 0.00" // [cite: 23]
        } else {
            binding.tvAmount.text = "$ $currentInput.00"
        }
    }
}