package com.example.missfinanzas

data class Gasto(
    val nombre: String,
    val monto: Double,
    val categoria: String,
    val esIngreso: Boolean = false // Nuevo campo
)