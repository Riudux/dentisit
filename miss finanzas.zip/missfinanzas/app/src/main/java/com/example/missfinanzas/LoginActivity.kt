package com.example.missfinanzas //

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.missfinanzas.databinding.ActivityLoginBinding // Importante para ViewBinding

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicialización de ViewBinding
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Configuración del botón de inicio de sesión [cite: 7]
        binding.btnLogin.setOnClickListener {
            val user = binding.etUser.text.toString() // [cite: 4]
            val pass = binding.etPass.text.toString() // [cite: 5]

            if (user.isNotEmpty() && pass.isNotEmpty()) {
                // Navegación funcional a MainActivity [cite: 9, 76]
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Complete todos los campos", Toast.LENGTH_SHORT).show()
            }
        }

        // Listener para crear cuenta [cite: 6]
        binding.tvCreateAccount.setOnClickListener {
            Toast.makeText(this, "Función de registro próximamente", Toast.LENGTH_SHORT).show()
        }
    }
}