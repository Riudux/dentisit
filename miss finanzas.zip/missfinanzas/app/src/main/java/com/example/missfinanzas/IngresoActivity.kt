package com.example.missfinanzas

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.missfinanzas.databinding.ActivityIngresoBinding

class IngresoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityIngresoBinding
    private var currentInput = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Asegúrate de que tu XML se llame actividad_ingreso.xml
        binding = ActivityIngresoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Botón de borrar (X)
        binding.btnDeleteIngreso.setOnClickListener {
            if (currentInput.isNotEmpty()) {
                currentInput = currentInput.dropLast(1)
                updateDisplay()
            }
        }

        // Botón Cancelar
        binding.btnCancelIngreso.setOnClickListener {
            finish()
        }

        // Botón Guardar (Enviar datos a MainActivity)
        binding.btnSaveIngreso.setOnClickListener {
            if (currentInput.isNotEmpty()) {
                val intent = Intent()
                intent.putExtra("MONTO", currentInput.toDouble())
                intent.putExtra("ES_INGRESO", true) // Importante: TRUE
                setResult(RESULT_OK, intent)
                finish()
            } else {
                Toast.makeText(this, "Por favor, ingrese un monto", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Esta función debe estar conectada en el XML en el atributo android:onClick="onNumberClick"
    fun onNumberClick(view: View) {
        val button = view as Button
        if (currentInput.length < 9) { // Evitar números demasiado grandes
            currentInput += button.text
            updateDisplay()
        }
    }

    private fun updateDisplay() {
        if (currentInput.isEmpty()) {
            binding.tvAmountIngreso.text = "$ 0.00"
        } else {
            // Formato visual para que se vea como dinero
            binding.tvAmountIngreso.text = "$ $currentInput.00"
        }
    }
}