package com.example.missfinanzas

import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class GastoAdapter(private val listaMovimientos: List<Gasto>) : RecyclerView.Adapter<GastoAdapter.GastoViewHolder>() {

    class GastoViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvNombre: TextView = view.findViewById(android.R.id.text1)
        val tvDetalle: TextView = view.findViewById(android.R.id.text2)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): GastoViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(android.R.layout.simple_list_item_2, parent, false)
        return GastoViewHolder(view)
    }

    override fun onBindViewHolder(holder: GastoViewHolder, position: Int) {
        val movimiento = listaMovimientos[position]

        if (movimiento.esIngreso) {
            holder.tvNombre.text = "Ingreso realizado: +$${movimiento.monto}"
            holder.tvNombre.setTextColor(Color.parseColor("#388E3C")) // Verde
            holder.tvDetalle.text = "Abono a cuenta"
        } else {
            holder.tvNombre.text = "${movimiento.categoria}: -$${movimiento.monto}"
            holder.tvNombre.setTextColor(Color.parseColor("#D32F2F")) // Rojo
            holder.tvDetalle.text = "Gasto realizado"
        }
    }

    override fun getItemCount() = listaMovimientos.size
}