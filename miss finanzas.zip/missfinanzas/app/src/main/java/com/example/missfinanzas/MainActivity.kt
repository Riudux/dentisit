package com.example.missfinanzas

import android.content.Intent
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.missfinanzas.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    // Variables de estado
    private var saldoActual = 0.0
    private var totalGastosSemana = 0.0
    private val listaDeMovimientos = mutableListOf<Gasto>()
    private lateinit var gastoAdapter: GastoAdapter

    // Receptor de resultados de AddActivity e IngresoActivity
    // Dentro del startForResult en MainActivity.kt
    private val startForResult = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == RESULT_OK) {
            val data = result.data
            val monto = data?.getDoubleExtra("MONTO", 0.0) ?: 0.0
            val esIngreso = data?.getBooleanExtra("ES_INGRESO", false) ?: false
            val categoria = data?.getStringExtra("CATEGORIA") ?: "Otros"

            if (esIngreso) {
                saldoActual += monto
                // AÑADIMOS EL INGRESO A LA LISTA
                val nuevoIngreso = Gasto("Ingreso", monto, "Abono", true)
                listaDeMovimientos.add(0, nuevoIngreso)
            } else {
                saldoActual -= monto
                totalGastosSemana += monto
                // AÑADIMOS EL GASTO A LA LISTA
                val nuevoGasto = Gasto("Gasto", monto, categoria, false)
                listaDeMovimientos.add(0, nuevoGasto)
            }

            // Notificar al adaptador y actualizar textos
            gastoAdapter.notifyItemInserted(0)
            binding.rvExpenses.scrollToPosition(0)
            actualizarInterfaz()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 1. Configurar RecyclerView (La lista de abajo)
        setupRecyclerView()

        // 2. Inicializar Interfaz en $0.00
        actualizarInterfaz()

        // 3. Botón + Ingreso
        binding.btnAddIncome.setOnClickListener {
            val intent = Intent(this, IngresoActivity::class.java)
            startForResult.launch(intent)
        }

        // 4. Botón + Gasto
        binding.btnAddExpense.setOnClickListener {
            val intent = Intent(this, AddActivity::class.java)
            startForResult.launch(intent)
        }

        // 5. Configuración del menú inferior para ir a Estadísticas
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_stats -> {
                    startActivity(Intent(this, CalendarActivity::class.java))
                    true
                }
                R.id.nav_home -> true
                else -> false
            }
        }
    }

    private fun setupRecyclerView() {
        gastoAdapter = GastoAdapter(listaDeMovimientos)
        binding.rvExpenses.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = gastoAdapter
        }
    }

    private fun actualizarInterfaz() {
        // Formatear a 2 decimales
        val saldoFormateado = "$${String.format("%.2f", saldoActual)}"
        val gastosFormateado = "Gastos esta semana: $${String.format("%.2f", totalGastosSemana)}"

        binding.tvAvailableBalance.text = saldoFormateado
        binding.tvWeeklyExpenses.text = gastosFormateado
    }
}