package com.example.dentisit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import com.google.firebase.auth.FirebaseAuth

class ConfiActivity : AppCompatActivity() {

    // Qué hace: Declaramos la variable de Firebase para saber quién está logueado.
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_confi)

        // Inicializamos Firebase
        auth = FirebaseAuth.getInstance()

        // --- REFERENCIAS DEL XML ---
        val btnCambiarPass: TextView = findViewById(R.id.btnCambiarPass)
        val btnEliminarCuenta: Button = findViewById(R.id.btnEliminarCuenta)
        val switchRecordatorios: SwitchCompat = findViewById(R.id.switchRecordatorios)
        val switchDarkMode: SwitchCompat = findViewById(R.id.switchDarkMode)

        // --- LÓGICA: CAMBIAR CONTRASEÑA ---
        // Qué hace: Envía un correo de recuperación al email del usuario actual.
        btnCambiarPass.setOnClickListener {
            val email = auth.currentUser?.email

            if (email != null) {
                auth.sendPasswordResetEmail(email)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            // Para qué sirve: El usuario recibe un link seguro en su correo.
                            Toast.makeText(this, "Correo enviado a: $email", Toast.LENGTH_LONG).show()
                        } else {
                            Toast.makeText(this, "Error al enviar correo", Toast.LENGTH_SHORT).show()
                        }
                    }
            }
        }

        // --- LÓGICA: ELIMINAR CUENTA ---
        // Qué hace: Muestra un cuadro de confirmación antes de borrar todo.
        btnEliminarCuenta.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("¿Eliminar cuenta?")
            builder.setMessage("Esta acción no se puede deshacer. Se borrarán todos tus datos de Dentisit.")

            // Si el usuario confirma:
            builder.setPositiveButton("Sí, eliminar") { _, _ ->
                val user = auth.currentUser
                user?.delete()?.addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // Para qué sirve: Limpia la sesión y lo manda al Login.
                        Toast.makeText(this, "Cuenta eliminada correctamente", Toast.LENGTH_SHORT).show()
                        val intent = Intent(this, LoginActivity::class.java)
                        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                    } else {
                        // Error común: Firebase pide que te hayas logueado hace poco para borrar cuenta.
                        Toast.makeText(this, "Error: Por seguridad, inicia sesión de nuevo antes de borrar tu cuenta", Toast.LENGTH_LONG).show()
                    }
                }
            }

            // Si el usuario cancela:
            builder.setNegativeButton("Cancelar", null)
            builder.show()
        }

        // --- LÓGICA: SWITCHES (SIMULACIÓN) ---
        switchRecordatorios.setOnCheckedChangeListener { _, isChecked ->
            val estado = if (isChecked) "activados" else "desactivados"
            Toast.makeText(this, "Recordatorios $estado", Toast.LENGTH_SHORT).show()
        }

        switchDarkMode.setOnCheckedChangeListener { _, isChecked ->
            Toast.makeText(this, "Modo oscuro en desarrollo", Toast.LENGTH_SHORT).show()
        }
    }
}