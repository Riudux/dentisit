package com.example.dentisit

import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PerfilDentistaActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_perfil_dentista)

        // --- 1. AJUSTE DE DISEÑO ---
        // Qué hace: Configura los márgenes para no chocar con la barra de estado.
        val mainView = findViewById<View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // --- 2. RECUPERAR DATOS DEL INTENT ---
        // Qué hace: Lee el nombre del usuario y el ID del dentista que mandó el Adapter.
        val nombreUsuario = intent.getStringExtra("USER_NAME") ?: "Usuario"
        val dentistaId = intent.getStringExtra("DENTISTA_ID") ?: "0"

        // --- 3. SALUDO PERSONALIZADO ---
        val tvGreeting = findViewById<TextView>(R.id.tvGreeting)
        tvGreeting.text = "¡Hola $nombreUsuario!"

        // --- 4. REFERENCIAS A LA INTERFAZ ---
        val tvNombreDentista = findViewById<TextView>(R.id.tvPerfilNombreDentista)
        val tvClinicaNombre = findViewById<TextView>(R.id.tvPerfilClinicaNombre)
        val cardCitas = findViewById<CardView>(R.id.cardProximasCitas)
        val tvCitaInfo = findViewById<TextView>(R.id.tvCitaDoctorEspecialidad)
        val tvCitaFecha = findViewById<TextView>(R.id.tvCitaFecha)

        // --- 5. LÓGICA DE DATOS (Simulación) ---
        // Qué hace: Dependiendo del ID que recibimos, mostramos un dentista u otro.
        val doctorSeleccionado = if (dentistaId == "1") {
            // Datos por defecto (Dr. Sebastian u otros)
            DentistaResult("1", "DR. SEBASTIAN", "Ortodoncia", "Francisco Villa", 5, null, "CLÍNICA DENTAL", "Dr. Juan Perez", "Odontología", "Hoy, 3:00 p.m", true)
        } else {
            // Datos para la Dra. Carla
            DentistaResult("2", "DRA. CARLA RODRÍGUEZ", "Odontología", "Dolores del Rio", 4, null, "DENTAL CENTER", null, null, null, false)
        }

        // --- 6. ASIGNAR TEXTOS A LA PANTALLA ---
        tvNombreDentista.text = doctorSeleccionado.nombre.uppercase()
        tvClinicaNombre.text = doctorSeleccionado.clinicaNombre?.uppercase()

        // Qué hace: Controla si se ve o no la tarjeta de citas.
        if (doctorSeleccionado.tieneCita) {
            cardCitas.visibility = View.VISIBLE
            tvCitaInfo.text = "${doctorSeleccionado.proximaCitaDoctor} - ${doctorSeleccionado.proximaCitaEspecialidad}"
            tvCitaFecha.text = doctorSeleccionado.proximaCitaFecha
        } else {
            cardCitas.visibility = View.GONE
        }
    }
}