package com.example.dentisit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// [IMPORTACIONES DE FIREBASE]
// Qué hace: Importa las librerías de autenticación y la base de datos de documentos.
// Para qué sirve: Para validar las credenciales del usuario y traer sus datos guardados.
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_login)

        // [AJUSTE DE INTERFAZ]
        // Qué hace: Calcula el espacio de las barras del sistema (notificaciones y navegación).
        // Para qué sirve: Para que los elementos visuales no queden ocultos detrás de las barras del teléfono.
        val mainLayout = findViewById<ConstraintLayout>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // [VINCULACIÓN DE COMPONENTES]
        // Qué hace: Conecta los objetos de Kotlin con los IDs definidos en el archivo XML.
        // Para qué sirve: Para poder manipular los textos y botones desde el código.
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPass = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val tvGoToRegister = findViewById<TextView>(R.id.tvGoToRegister)

        // [INSTANCIAS DE SERVICIOS]
        val auth = FirebaseAuth.getInstance()
        val db = FirebaseFirestore.getInstance()

        // [EVENTO DE CLIC EN LOGIN]
        btnLogin.setOnClickListener {
            // Qué hace: Captura el texto ingresado y limpia espacios en blanco.
            // Para qué sirve: Evitar errores de escritura al comparar con la base de datos.
            val email = etEmail.text.toString().trim()
            val password = etPass.text.toString().trim()

            // [VALIDACIÓN LOCAL]
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Ingresa correo y contraseña", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // [PROCESO DE AUTENTICACIÓN]
            // Qué hace: Envía los datos a Firebase para verificar si el usuario existe y la clave es correcta.
            // Para qué sirve: Dar acceso seguro a la aplicación.
            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // [PROCESO DE LECTURA DE DATOS]
                        // Qué hace: Busca el ID del usuario recién logueado.
                        // Para qué sirve: Localizar su información específica en Firestore.
                        val userId = auth.currentUser?.uid

                        if (userId != null) {
                            // Qué hace: Entra a la colección "usuarios" y pide el documento con el ID del usuario.
                            // Para qué sirve: Obtener el nombre real que guardamos en el registro.
                            db.collection("usuarios").document(userId).get()
                                .addOnSuccessListener { document ->
                                    val nombre = document.getString("nombre") ?: "Usuario"

                                    // [SALTO A PANTALLA PRINCIPAL]
                                    // Qué hace: Crea una intención para abrir HomeActivity y le pasa el nombre.
                                    // Para qué sirve: Mostrar un saludo personalizado en la siguiente pantalla.
                                    val intent = Intent(this, HomeActivity::class.java)
                                    intent.putExtra("USER_NAME", nombre)
                                    startActivity(intent)
                                    finish() // Qué hace: Cierra el login. Para qué sirve: Que el usuario no regrese al login con el botón 'atrás'.
                                }
                        }
                    } else {
                        // Qué hace: Muestra el error técnico devuelto por Firebase (ej. contraseña incorrecta).
                        // Para qué sirve: Que el usuario sepa exactamente por qué no pudo entrar.
                        Toast.makeText(this, "Error: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        // [IR A REGISTRO]
        tvGoToRegister.setOnClickListener {
            // Qué hace: Abre la actividad de registro.
            // Para qué sirve: Permitir que usuarios nuevos creen una cuenta.
            val intent = Intent(this, RegisterActivity::class.java)
            startActivity(intent)
        }
    }
}