package com.example.dentisit

// Qué hace: Es una clase de datos (molde) para representar a un dentista.
// Para qué sirve: Para que Kotlin sepa que un "Dentista" tiene nombre, especialidad, etc.
data class DentistaResult(
    val id: String,                          // ID único para identificar al doctor
    val nombre: String,                      // Nombre completo (ej. DRA. CARLA RODRÍGUEZ)
    val especialidad: String,                // Ej. Ortodoncia
    val direccion: String,                   // Ubicación de la clínica
    val estrellas: Int,                      // Calificación (1 a 5)
    val fotoUrl: String? = null,             // URL de la foto (opcional)
    val clinicaNombre: String? = "Clínica",   // Nombre del consultorio
    val proximaCitaDoctor: String? = null,   // Nombre del doctor de la cita
    val proximaCitaEspecialidad: String? = null, // Especialidad de la cita
    val proximaCitaFecha: String? = null,    // Fecha y hora (ej. Hoy, 3:00 p.m)
    val tieneCita: Boolean = false           // ¿Mostramos la tarjeta de "Próximas citas"?
)