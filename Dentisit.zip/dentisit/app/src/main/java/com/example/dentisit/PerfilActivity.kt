package com.example.dentisit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class PerfilActivity : AppCompatActivity() {

    // Qué hace: Variable para manejar la sesión del usuario.
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        // Qué hace: Inicializamos la conexión con Firebase Auth (Esto es gratis).
        auth = FirebaseAuth.getInstance()

        // --- REFERENCIAS DEL XML ---
        val tvNombre: TextView = findViewById(R.id.tvNombrePerfil)
        val tvCorreo: TextView = findViewById(R.id.tvCorreoPerfil)
        val btnLogout: Button = findViewById(R.id.btnLogout)
        val imgProfile: ImageView = findViewById(R.id.imgProfileUser)

        // --- CARGAR DATOS DEL USUARIO ---
        // Qué hace: Obtenemos al usuario que tiene la sesión abierta.
        val user = auth.currentUser

        if (user != null) {
            // Qué hace: Ponemos el correo real que viene de Firebase.
            tvCorreo.text = user.email ?: "Sin correo"

            // Qué hace: Ponemos el nombre. Si Firebase no lo tiene, ponemos un texto amigable.
            tvNombre.text = user.displayName ?: "Paciente de Dentisit"

            // --- Lógica del Avatar ---
            // Para qué sirve: Como no usamos Storage, ponemos una imagen fija de tu drawable.
            // Así la app siempre se ve bien y no gasta datos ni dinero.
            imgProfile.setImageResource(R.drawable.ic_dentist_logo)
        }

        // --- LÓGICA: CERRAR SESIÓN ---
        // Qué hace: Borra la sesión activa y limpia la memoria.
        btnLogout.setOnClickListener {
            // Para qué sirve: Le dice a Firebase que el usuario salió.
            auth.signOut()

            // Qué hace: Crea el pase para ir al LoginActivity.
            val intent = Intent(this, LoginActivity::class.java)

            // Para qué sirve: Estas banderas evitan que el usuario regrese con el botón "Atrás".
            // Básicamente resetean el historial de pantallas.
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK

            startActivity(intent)

            // Qué hace: Cierra esta pantalla (Perfil) definitivamente.
            finish()

            Toast.makeText(this, "Has salido de Dentisit", Toast.LENGTH_SHORT).show()
        }
    }
}