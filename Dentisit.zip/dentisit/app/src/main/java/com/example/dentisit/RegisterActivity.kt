package com.example.dentisit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// [IMPORTACIONES DE FIREBASE]
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.userProfileChangeRequest // Qué hace: Importa la herramienta para cambiar el nombre visible.
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        // [CONFIGURACIÓN DE DISEÑO]
        // Qué hace: Ajusta la pantalla para que no choque con la barra de notificaciones del celular.
        val mainLayout = findViewById<ConstraintLayout>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // [INICIALIZACIÓN DE VISTAS]
        // Qué hace: Vincula el diseño XML con las variables de Kotlin.
        val etFullName = findViewById<EditText>(R.id.etRegName)
        val etEmail = findViewById<EditText>(R.id.etRegEmail)
        val etPass = findViewById<EditText>(R.id.etRegPassword)
        val etConfirm = findViewById<EditText>(R.id.etRegConfirmPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegisterAccount)
        val tvGoToLogin = findViewById<TextView>(R.id.tvGoToLogin)

        // [INSTANCIAS DE FIREBASE]
        val auth = FirebaseAuth.getInstance()
        val db = FirebaseFirestore.getInstance()

        // [EVENTO DE REGISTRO]
        btnRegister.setOnClickListener {
            // Qué hace: Captura lo que escribió el usuario.
            val name = etFullName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPass.text.toString().trim()
            val confirmPassword = etConfirm.text.toString().trim()

            // [VALIDACIONES BÁSICAS]
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // [PASO 1: CREAR USUARIO EN AUTH]
            // Qué hace: Crea la cuenta con correo y clave.
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val user = auth.currentUser
                        val userId = user?.uid

                        // [NUEVO PASO: ACTUALIZAR NOMBRE EN EL PERFIL DE AUTH]
                        // Qué hace: Crea una petición para que Firebase Auth guarde el nombre del usuario.
                        // Para qué sirve: Para que en el Home y Perfil aparezca el nombre sin buscar en Firestore.
                        val profileUpdates = userProfileChangeRequest {
                            displayName = name
                        }

                        user?.updateProfile(profileUpdates)
                            ?.addOnCompleteListener { profileTask ->
                                if (profileTask.isSuccessful) {
                                    // El nombre ya se guardó en el sistema de cuentas.
                                }
                            }

                        // [PASO 2: GUARDAR DATOS EN FIRESTORE]
                        // Qué hace: Crea una "ficha" con información extra del paciente.
                        val userProfile = hashMapOf(
                            "nombre" to name,
                            "correo" to email,
                            "rol" to "paciente",
                            "fecha_registro" to com.google.firebase.Timestamp.now()
                        )

                        // Qué hace: Guarda la ficha en la colección "usuarios" usando el ID único (userId).
                        if (userId != null) {
                            db.collection("usuarios").document(userId)
                                .set(userProfile)
                                .addOnSuccessListener {
                                    // Qué hace: Avisa que todo salió bien y nos manda al Home.
                                    Toast.makeText(this, "¡Bienvenido a Dentisit!", Toast.LENGTH_SHORT).show()

                                    val intent = Intent(this, HomeActivity::class.java)
                                    // Para qué sirve: Limpia el historial para que no pueda regresar al registro con el botón "atrás".
                                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    startActivity(intent)
                                    finish()
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this, "Error en base de datos: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                        }
                    } else {
                        // Qué hace: Muestra el error exacto si falla el registro (ej: correo inválido).
                        Toast.makeText(this, "Error: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        // [VOLVER AL LOGIN]
        tvGoToLogin.setOnClickListener {
            // Qué hace: Cierra esta pantalla para volver a la anterior.
            finish()
        }
    }
}