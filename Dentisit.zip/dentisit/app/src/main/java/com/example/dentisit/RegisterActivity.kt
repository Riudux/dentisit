package com.example.dentisit

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
// [IMPORTACIONES DE FIREBASE]
// Qué hace: Importa las herramientas de autenticación y base de datos.
// Para qué sirve: Permite crear cuentas de usuario y guardar documentos en la nube.
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_register)

        // [CONFIGURACIÓN DE DISEÑO]
        // Qué hace: Ajusta el padding de la vista principal según las barras del sistema (estado/navegación).
        // Para qué sirve: Evita que el contenido de la app se encime con la hora o los botones del celular.
        val mainLayout = findViewById<ConstraintLayout>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainLayout) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // [INICIALIZACIÓN DE VISTAS]
        // Qué hace: Vincula las variables de Kotlin con los elementos visuales del XML.
        // Para qué sirve: Para poder leer lo que el usuario escribe y detectar sus clics.
        val etFullName = findViewById<EditText>(R.id.etRegName) // Asegúrate que este ID exista en tu XML
        val etEmail = findViewById<EditText>(R.id.etRegEmail)    // Campo para el correo
        val etPass = findViewById<EditText>(R.id.etRegPassword)
        val etConfirm = findViewById<EditText>(R.id.etRegConfirmPassword)
        val btnRegister = findViewById<Button>(R.id.btnRegisterAccount)
        val tvGoToLogin = findViewById<TextView>(R.id.tvGoToLogin)

        // [INSTANCIAS DE FIREBASE]
        val auth = FirebaseAuth.getInstance()
        val db = FirebaseFirestore.getInstance()

        // [EVENTO DE REGISTRO]
        btnRegister.setOnClickListener {
            // Qué hace: Obtiene el texto de los inputs y elimina espacios accidentales.
            // Para qué sirve: Tener los datos limpios para enviarlos a la base de datos.
            val name = etFullName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val password = etPass.text.toString().trim()
            val confirmPassword = etConfirm.text.toString().trim()

            // [VALIDACIONES BÁSICAS]
            if (name.isEmpty() || email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Por favor, llena todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password != confirmPassword) {
                Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // [PASO 1: CREAR USUARIO EN AUTH]
            // Qué hace: Registra el correo y contraseña en el sistema de accesos de Firebase.
            // Para qué sirve: Generar una cuenta válida para que el usuario pueda iniciar sesión.
            auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        // [PASO 2: OBTENER ID ÚNICO]
                        // Qué hace: Extrae el UID (User ID) que Firebase generó automáticamente.
                        // Para qué sirve: Usarlo como nombre del documento para que la info esté vinculada.
                        val userId = auth.currentUser?.uid

                        // [PASO 3: PREPARAR FICHA DE USUARIO]
                        // Qué hace: Crea un mapa con los datos adicionales (nombre, rol, etc).
                        // Para qué sirve: Guardar información que la pestaña de 'Auth' no puede almacenar.
                        val userProfile = hashMapOf(
                            "nombre" to name,
                            "correo" to email,
                            "rol" to "paciente",
                            "fecha_registro" to com.google.firebase.Timestamp.now()
                        )

                        // [PASO 4: GUARDAR EN FIRESTORE]
                        // Qué hace: Crea un documento en la colección 'usuarios' con los datos del mapa.
                        // Para qué sirve: Tener una base de datos real con los nombres de tus pacientes.
                        if (userId != null) {
                            db.collection("usuarios").document(userId)
                                .set(userProfile)
                                .addOnSuccessListener {
                                    // Qué hace: Muestra éxito y cierra la actividad de registro.
                                    // Para qué sirve: Informar al usuario y regresarlo al login o enviarlo al Home.
                                    Toast.makeText(this, "¡Cuenta y perfil creados!", Toast.LENGTH_SHORT).show()
                                    finish()
                                }
                                .addOnFailureListener { e ->
                                    Toast.makeText(this, "Error al guardar perfil: ${e.message}", Toast.LENGTH_LONG).show()
                                }
                        }
                    } else {
                        // Qué hace: Captura errores como "el correo ya existe" o "internet lento".
                        // Para qué sirve: Evitar que el usuario se quede sin saber por qué falló el botón.
                        Toast.makeText(this, "Error: ${task.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
        }

        // [VOLVER AL LOGIN]
        tvGoToLogin.setOnClickListener {
            // Qué hace: Cierra la pantalla de registro.
            // Para qué sirve: Regresar a la pantalla anterior (LoginActivity).
            finish()
        }
    }
}