package com.example.dentisit

import android.annotation.SuppressLint
import android.content.Context
import android.location.LocationManager
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
// [IMPORTACIONES DE FIREBASE]
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class HomeActivity : AppCompatActivity() {

    // @SuppressLint: Qué hace: Ignora advertencias específicas del compilador.
    // Para qué sirve: Evita avisos sobre el uso de JavaScript en WebView o textos hardcoded.
    @SuppressLint("SetTextI18n", "SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)

        // --- 1. CONFIGURACIÓN DE MÁRGENES (SISTEMA) ---
        // Qué hace: Detecta el tamaño de las barras de estado y navegación del dispositivo.
        // Para qué sirve: Aplica un margen (padding) automático para que el diseño no se corte en pantallas con "notch".
        val mainView = findViewById<android.view.View>(R.id.main)
        ViewCompat.setOnApplyWindowInsetsListener(mainView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // --- 2. SALUDO PERSONALIZADO (FIRESTORE) ---
        val tvGreeting = findViewById<TextView>(R.id.tvGreeting)

        // Qué hace: Intenta obtener el nombre enviado desde el LoginActivity.
        // Para qué sirve: Mostrar el nombre inmediatamente sin esperar a la base de datos.
        val nombreRecibido = intent.getStringExtra("USER_NAME")

        if (nombreRecibido != null) {
            tvGreeting.text = "¡Hola $nombreRecibido!"
        } else {
            // [PLAN B: CONSULTA A FIRESTORE]
            // Qué hace: Si el Intent llegó vacío, busca el ID del usuario actual y consulta su documento en la nube.
            // Para qué sirve: Garantizar que el saludo siempre muestre el nombre real del usuario logueado.
            val userId = FirebaseAuth.getInstance().currentUser?.uid
            if (userId != null) {
                FirebaseFirestore.getInstance().collection("usuarios").document(userId).get()
                    .addOnSuccessListener { document ->
                        val nombreBD = document.getString("nombre")
                        tvGreeting.text = "¡Hola $nombreBD!"
                    }
            }
        }

        // --- 3. CONFIGURACIÓN DEL MAPA (WEBVIEW + GPS) ---
        val webViewMapa = findViewById<WebView>(R.id.webViewMapa)

        // Qué hace: Habilita la ejecución de scripts dentro del cuadro del mapa.
        // Para qué sirve: Permitir que la librería Leaflet (JavaScript) pueda dibujar el mapa interactivo.
        webViewMapa.settings.javaScriptEnabled = true
        webViewMapa.webViewClient = WebViewClient()

        // Qué hace: Solicita el servicio de localización del sistema Android.
        // Para qué sirve: Poder acceder a las coordenadas GPS del celular.
        val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager

        // Qué hace: Intenta obtener la última ubicación guardada por red o satélite.
        // Para qué sirve: Centrar el mapa en la posición real del usuario.
        val location = try {
            locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                ?: locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
        } catch (e: SecurityException) {
            null // Qué hace: Captura el error si el usuario no dio permisos de GPS.
        }

        // Qué hace: Define coordenadas de Durango, México, como respaldo.
        // Para qué sirve: Que el mapa no aparezca en blanco si el GPS está apagado.
        val lat = location?.latitude ?: 24.022093
        val lon = location?.longitude ?: -104.659398

        // Qué hace: Define un bloque de texto con código HTML y CSS.
        // Para qué sirve: Cargar el mapa de OpenStreetMap usando variables de Kotlin ($lat, $lon).
        val contenidoHtml = """
            <!DOCTYPE html>
            <html>
            <head>
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
                <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
                <style>
                    #map { height: 100vh; width: 100vw; margin: 0; padding: 0; }
                    body { margin: 0; overflow: hidden; }
                </style>
            </head>
            <body>
                <div id="map"></div>
                <script>
                    // Qué hace: Inicializa el mapa en las coordenadas detectadas.
                    var map = L.map('map').setView([$lat, $lon], 16); 
                    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                        attribution: '&copy; OSM'
                    }).addTo(map);
                    // Qué hace: Dibuja un pin azul en la ubicación.
                    L.marker([$lat, $lon]).addTo(map)
                        .bindPopup('Tu ubicación actual')
                        .openPopup();
                </script>
            </body>
            </html>
        """.trimIndent()

        // Qué hace: Carga el HTML generado dentro del componente WebView.
        // Para qué sirve: Mostrar visualmente el mapa dentro de la aplicación.
        webViewMapa.loadDataWithBaseURL(null, contenidoHtml, "text/html", "UTF-8", null)

        // --- 4. CONFIGURACIÓN DEL RECYCLERVIEW (LISTA DE DENTISTAS) ---

        val rvResultados = findViewById<RecyclerView>(R.id.rvResultadosDentistas)

        // Qué hace: Establece una disposición lineal (uno debajo de otro).
        // Para qué sirve: Que la lista de dentistas se pueda desplazar verticalmente.
        rvResultados.layoutManager = LinearLayoutManager(this)

        // Qué hace: Crea una lista de objetos "DentistaResult" con datos estáticos.
        // Para qué sirve: Simular los resultados de búsqueda de la clínica.
        val dentistasResultadosEjemplo = listOf(
            DentistaResult("1", "Dr. Sebastian", "Ortodoncia", "Blvr. Dolores del rio", 3),
            DentistaResult("2", "Dr. Lucas", "Ortodoncia y Estetica Dental", "Blvr. Dolores del rio", 4),
            DentistaResult("3", "Dra. Maria", "Ortodoncia", "Zona Centro, 5 febrero", 3),
            DentistaResult("4", "Dra. Carla Rodriguez", "Ortodoncia", "Blvr. Francisco Villa", 5)
        )

        // Qué hace: Instancia el adaptador y lo asigna al RecyclerView.
        // Para qué sirve: El adaptador es el "traductor" que convierte los datos de la lista en tarjetas visuales.
        val adapter = DentistaResultAdapter(dentistasResultadosEjemplo)
        rvResultados.adapter = adapter
    }
}